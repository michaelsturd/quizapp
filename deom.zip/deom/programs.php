<?php
// echo $_POST['fullname']." Good morning.";

// echo $_POST['tested'];

// $true_answer = "World health organization";
// if ($_POST['tested'] == $true_answer) {
    
//     echo "<br> You Are Right ANd You Have Won $50,000";
// }
// else{
//     echo "<br> You Are Wrong And You Have Seriously Failed";
// }


// $plateofmeal = $_POST['plateofmeal'];
// $nopo = $_POST['nopo'];
// $amount_paid = $_POST['amount_paid'];

// echo "YOu have just ordered ".$nopo. " of ".$plateofmeal;
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" action="result.php" style="display:block; width:50%; margin:100px auto;">
            <h1>What is the mean full meaning of WHO?</h1>
            <select name="question1" id="">
                <option value="World health organization">World health organization</option>
                <option value="World heart organization">World heart organization</option>
                <option value="Who's health organization">Who's health organization</option>
            </select>
            <br><br>
            <h1>What is the capital of delta</h1>
        <select name="question2" id="">
            <option value="Warri">Warri</option>
            <option value="Ughelli">Ughelli</option>
            <option value="Asaba">Asaba</option>
        </select>
        <br><br>
        <h1>Where do we take sick people to?</h1>
        <select name="question3" id="">
            <option value="Church">Church</option>
            <option value="School">School</option>
            <option value="Hospital">Hospital</option>
        </select>



        <!-- <input type="text" name="fullname" placeholder="Enter fullname"><br> -->
        <!-- <input type="text" name="price" name="fullname" placeholder="Enter price"><br> -->
        <!-- <input type="text" name="quantity" name="fullname" placeholder="Enter quantity"><br> -->
        <button type="submit">Submit</button>
    </form>
</body>
</html>