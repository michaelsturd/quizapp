<?php
$question1 = $_POST['question1'];
$question2 = $_POST['question2'];
$question3 = $_POST['question3'];

$ans1 = "World health organization";
$ans2 = "Asaba";
$ans3 = "Hospital";

echo "Question1:    What is the full meaning of WHO? <br>";
echo "<i> Ans: ".$question1."</i><br><br>" ;

echo "Question2:    What is the capital of delta? <br>" ;
echo "<i> Ans: ".$question2."</i><br><br>" ;

echo "Question3:    Where do we take sick people to? <br>";
echo "<i> Ans: ".$question3."</i>" ;

echo "<hr>";

if($ans1 == $question1){
    echo "<br> Your answer is correct $ans1";
}
else{
    echo "<br>incorrect";
}

if($ans2 == $question2){
    echo "<br> Your answer is correct $ans2";
}
else{
    echo "<br> incorrect";
}

if($ans3 == $question3){
    echo "<br> Your answer is correct $ans3<br><span class='green'></span>";
}
else{
    echo "<br>incorrect";
}

if ($ans1 == $question1 & $ans2 == $question2 & $ans3 == $question3) {
    echo "<br><h1>Congratulation You Have Won N50,000 Nigeria Naira</h1>";
}
else{
    echo "<br><h1>You Have Bitterly Failed, Come Back Next Year</h1>";
}

echo "<br><br><hr><a href='programs.php'>Back</a>";

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .green{
            display:block;
            width:50px;
            height:50px;
        }
    </style>
</head>
<body>
    
</body>
</html>